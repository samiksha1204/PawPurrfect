<?php
require('config.php');
// echo '<pre>';
// print_r($_POST);
// echo "$_POST['shelter']";
//stripetoken very important
if (isset($_POST['stripeToken']))
{
    $token= $_POST['stripeToken'];
        header("Location: success.php");
    
    // $data  = \Stripe\Charge::create(array(
    //     "amount" => data-amount
    //     "currency" => "inr",
    //     "description" => "PawPurrfect",
    //     "source"=> $token,
    // ));
echo "<pre>";
print_r($data);
}


?>
