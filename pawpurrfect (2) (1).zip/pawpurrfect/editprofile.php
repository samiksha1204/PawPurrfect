<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link rel="stylesheet" href="css/editprofile.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

    <link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="css/editprofile.css">
</head>
<body>
    <?php include 'header.php';?>
    <?php include 'dbconnect.php';?>
   <?php function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
#session_start(); 

$uid=$_SESSION['user_id'];
if($uid<100)
$query="select uid,fname,lname,email,contact,location from users where uid ='$uid';";
else
$query=" select aid,name,email,contact,address from animal_shelter where aid ='$uid';";
$result = mysqli_query($con,$query);// or header("Location: error.php","http_response_code:400");;
if(!$result){
  echo mysqli_error($con);
  //header("Location: error.php","http_response_code:400");
}
$row=mysqli_fetch_array($result);

?>
    <div class="container">
        <h3>Edit Profile</h3>
          <hr>
        
          
          <!-- edit form column -->
          <div class="col-md-9 personal-info">
            
            
            <form class="form-horizontal" role="form" name="edit_prof"  action="editprofile.php" method='POST'>
              <div class="form-group">
                <label class="col-lg-3 control-label">First name:</label>
                <div class="col-lg-8">
                  <input class="form-control" type="text" name="fnm" value=<?php if ($uid<100) echo $row['fname']; else echo $row['name']; ?> readonly>
                </div>
              </div>
              <?php  if ($uid<100){ 
              echo '<div class="form-group">';
              echo '<label class="col-lg-3 control-label">Last name:</label>';
              echo '<div class="col-lg-8">';
              echo '<input class="form-control" type="text"  name="lnm" value="'.$row['lname'].'" readonly>';
              echo '</div>';
              echo '</div>';}
              ?>
              
             
              <div class="form-group">
                <label class="col-lg-3 control-label" >Email:</label>
                <div class="col-lg-8">
                  <input class="form-control" type="text" name="em" value=<?php echo $row['email'] ?> readonly>
                </div>
              </div>
              <div class="form-group">
                <label class="col-lg-3 control-label" >Contact:</label>
                <div class="col-lg-8">
                  <input class="form-control" type="text" name="con" value=<?php echo $row['contact'] ?> >
                </div>
              </div>
              <div class="form-group">
                <label class="col-lg-3 control-label">Location:</label>
                <div class="col-lg-8">
                  <div class="ui-select">
                    <select name="loc" id="city" onclick="citylist()" class="form-control" required>
                      <option value=<?php if($uid<99)echo $row['location']; else echo $row['address']; ?>  selected><?php if($uid<99)echo $row['location']; else echo $row['address']; ?></option>
                    </select>
                    <!-- <select id="user_time_zone" class="form-control">
                      <option value="Hawaii">(GMT-10:00) Hawaii</option>
                      <option value="Alaska">(GMT-09:00) Alaska</option>
                      <option value="Pacific Time (US &amp; Canada)">(GMT-08:00) Pacific Time (US &amp; Canada)</option>
                      <option value="Arizona">(GMT-07:00) Arizona</option>
                      <option value="Mountain Time (US &amp; Canada)">(GMT-07:00) Mountain Time (US &amp; Canada)</option>
                      <option value="Central Time (US &amp; Canada)" selected="selected">(GMT-06:00) Central Time (US &amp; Canada)</option>
                      <option value="Eastern Time (US &amp; Canada)">(GMT-05:00) Eastern Time (US &amp; Canada)</option>
                      <option value="Indiana (East)">(GMT-05:00) Indiana (East)</option>
                    </select> -->
                  </div>
                </div>
              </div>
              <!-- <div class="form-group">
                <label class="col-md-3 control-label">Username:</label>
                <div class="col-md-8">
                  <input class="form-control" type="text" value="janeuser">
                </div>
              </div> -->
              <!-- <div class="form-group">
                <label class="col-md-3 control-label">Password:</label>
                <div class="col-md-8">
                  <input class="form-control" type="password" value="11111122333">
                </div>
              </div>
              <div class="form-group">
                <label class="col-md-3 control-label">Confirm password:</label>
                <div class="col-md-8">
                  <input class="form-control" type="password" value="11111122333">
                </div>
              </div> -->
              <div class="form-group">
                <label class="col-md-3 control-label"></label>
                <div class="col-md-8">
                  <input type="submit" class="btn btn-primary" value="Save Changes" name="change_btn">
                  <span></span>
                  <input type="reset" class="btn btn-default" value="Cancel" name="fill_btn">
                </div>
              </div>
            </form>
          </div>
      </div>
    </div>
  
    <?php include 'footer.php';?>
    <script>
      function citylist(){
      var cities =['Delhi','Mumbai','Kolkata','Bangalore','Chennai','Vellore'];
  //sort in ascending order
  var sort = cities.sort();
  var input = document.getElementById("city");
  for (i=0; i < 6;i++){
      var op = document.createElement("option");
      op.setAttribute("value",sort[i]);
      op.setAttribute("name","city");
      // if (sort[i]==<?php echo json_encode($row['location']);?>){
      //   //console.log(sort[i]);
      // op.selected=true;
      // }
      op.innerText = sort[i];
      input.appendChild(op);
  }
  }
    </script>
</body>
<?php 
if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['change_btn'])){
 
  if ($uid>99){
    $query="update animal_shelter set contact=".$_POST['con'].",location='".$_POST['loc']."' where aid=".$uid;
  }
  else{
    $query="update users set contact=".$_POST['con'].",location='".$_POST['loc']."' where uid=".$uid;
  }
$result = mysqli_query($con,$query);// or header("Location: error.php","http_response_code:400");;
if(!$result){
  echo mysqli_error($con);
  //header("Location: error.php","http_response_code:400");
}
else{
  echo "<script> alert('Profile updated successfully');</script>";
  header("Location: editprofile.php");
}
//$row=mysqli_fetch_array($result);

  }
else if (isset($_POST['fill_btn'])){
  //fill_profile();
  header("Location: editprofile.php");
}
?>
</html>