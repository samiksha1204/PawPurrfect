<?php

echo "<h1>Unable to connect to server. Please try again</h1>";
?>