<?php
        require('config.php');
        ?>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
    <style>
        html { 
    background: url('bg.jpg') no-repeat center center fixed; 
    -webkit-background-size: cover;
    -moz-background-size: cover;
    -o-background-size: cover;
    background-size: cover;
    font-family: 'Hubballi';
    color:white;
  }
  body{
      margin-top:150px;
  }
h1{
    text-align:center;
}
.container{
    padding:10px;
}
form{
    width: fit-content;
    margin: 0 auto;
    padding: 20px;
    background-color: rgba(188, 143, 143, 0.822);
    background: rgba(0,0,0,0.2);

}
.form-group{
    margin-bottom: 40px;
    width: 100%;
}

label{
    display: block;
    font-size: 1.3rem;
    font-weight: 600;
    
}
.form-control{
  display: block;
  margin-top: 10px;
  padding: 10px;
  width: 86%;
  font-size: 1rem;
  border-radius: 5px;
  color: gray;
  outline: none;
  font-weight: 500;
  border: none;
    border-color: transparent;
    resize: none;
    outline: none;
}


#submit{
    width: 100%;
    padding: 10px;
    background-color: darkturquoise;
    border: none;
    border-radius: 5px;
    font-size: 20px;
    /* text-transform : uppercase; */
    font-weight: bold;
    color: white;
    outline:none;
    border: none;
    resize: none;
    outline: none;
}

.form-control:focus,
.form-control:active {
  border-color: transparent;
  outline: none;
  /* border: 3px solid rosybrown; */
}

select{
    background-color: white;
}
    </style>
</head>
  <body>
      <h1>Make a Difference</h1>
      <div class="container">
      <form name="recipient" action="12.php" method="post" onsubmit="return validate();">
        <div class="form-group">
            <label for="shelter">Donate To</label>
            <select name="shelter" id="shelter" required class="form-control">
                <option value="Choose">Choose</option>
                <option value="Animal Kindness">Animal Kindness</option>
                <option value="Animal Adoption Center">Animal Adoption Center</option>
                <option value="Furry Friends">Furry Friends</option>
                <option value="Kindness shelter">Kindness shelter</option>
            </select>
        </div>
        <div class="form-group">
        <label for="amount">Enter amount </label><input type="text" name="amount" id="amount" required class="form-control">
        </div>
        <div class="form-group">
        <input type="submit" value="Pay" id="submit">
        </div>
        
       
        
</form>

    </div>
    <script>
        function validate()
        {
            var shelter = document.recipient.shelter;
            console.log(shelter);
            var amt = document.recipient.amount;
            if(shelter_valid(shelter))
            {
                if(amt_valid(amt))
                {
                    return true;
                }
            }
            return false;
        }
        function shelter_valid(shelter)
        {
            if(shelter.selectedIndex <=0)
            {
            alert("Please Select Animal Shelter");
            return false;
            }
            else return true;
        }
        function amt_valid(amt){
            A = Number(amt.value);
            if (A > 100)
            {
                return true;
            }
            else{
                alert('Minimum Donation is Rs 100');
            }
        }
        
    </script>

</body>
</html>