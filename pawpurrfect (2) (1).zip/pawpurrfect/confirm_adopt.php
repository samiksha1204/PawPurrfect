<?php
session_start();
if(isset($_SESSION['user_id'])){
$animi=$_COOKIE['animid'];
$server='localhost';
        $us='root';
        $con=mysqli_connect($server,$us,'');
        if(!$con){
            header("Location: error.php","http_response_code:400");
        }
        $dbname='pawpurrfect';
        mysqli_select_db($con,$dbname);
        $query="update animal set active=0 where animal_id=".$animi;
      $result = mysqli_query($con,$query);
}
else{
    echo '<script>alert("Please login to adopt ")</script>';
    header("Location: logreg.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/petdetsstyle.css">
        <title>Animal Details</title>
    </head>
    <body>
    <div id="main">
    <header>
        <h1 class="name">Thank you for adopting!</h1>
    </header>
            <?php 
                //session_start();
                if(isset($_SESSION['user_id'])){
                    $animi=$_COOKIE['animid'];
                $dbname='pawpurrfect';
                mysqli_select_db($con,$dbname);
                $query = "(select uid,fname,contact from users where uid=(select uid from animal where animal_id =3 and uid<>99)) union( select aid,name,contact from animal_shelter where aid=(select aid from animal where animal_id =3 and aid<>99));";
      $result = mysqli_query($con,$query);
      if(!$result){
        echo mysqli_error($con);
      }
      $row=mysqli_fetch_array($result);

                }
                else{
                    echo '<script>alert("Please login before proceeding for adoption.");</script>';
                    header("Location: register.php");
                }
                ?>

<div class="pet">
                <p>Do visit the links on <a href='grooming.php'>grooming centers</a> to begin your journey as a pet parent!</p>
                    <ul>
                        <li><?php echo "Contact ".$row['fname']." on ".$row['contact']." to complete the procedure"; ?></li>  
                        <li>
                            
                            <a href="homepage.php">Go to home page</a>
                        </li>
                    </ul>
            </div>
            </div>
    
    </body>
</html>