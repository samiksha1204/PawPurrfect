let Shops = {
    data: [
      {
        ShopName: "Pow Bow Grooming",
        category: "Delhi",
        Address: "457/10, Ram Pura, Tri Nagar, Delhi 110035",
        mob : "Phone number  01127192312",
        image: "images/groom1.jpg",
      },
      {
        ShopName: "Purplebone",
        category: "Mumbai",
        Address: "Gd Valuer19bnk St, 2nd Flr, Sonawala Bldg, Near Old Custom House, Mumbai 400001",
        mob:"Phone number  02222663733",
        image: "images/groom2.jpg",
      },
      {
        ShopName: "Foxy Groomers",
        category: "Mumbai",
        Address: "Gr Fl, Meghdoot Bldg, Sambhaji Rd, Vishnu Nagar, Thane(w),Mumbai 400602",
        mob:"Phone number  02225377292",
        image: "images/groom3.jpg",
      },
      {
        ShopName:"Pet Universe Cat & Dog Grooming Salon",
        category: "Delhi",
        mob:"Phone Number 28451021",
        Address: "104 Veena Ind. Estate, New Link Rd, Andheri (west), Mumbai 400053",
        image: "images/groom4.jpg",
      },
      {
        ShopName: "Pawfect Style Dog Grooming",
        category: "Mumbai",
        mob:"Phone number  02228752195",
        Address: "Shed No. 1, Plot No. 2, Udyog Nagar, S V Road, Opp Kamats Club, Goregaon (w), Mumbai 400062",
        image: "images/groom5.jpg",
      },
      {
        ShopName: "La Maison des Chiens",
        category: "Chennai",
        mob:"Phone number  04424759528",
        Address: "Cp-30, Mmda Clny, Arumbakkam, Chennai  600106 ",
        image: "images/groom6.jpg",
      },
      {
        ShopName: "Short Bark & Sides",
        category: "Kolkata",
        mob:"Phone number  4145198621",
        Address: "12a/23, Vivekanand Road Kolkata 700006",
        image: "images/groom7.jpg",
      },
      {
        ShopName: "The mutt hutt",
        category: "Chennai",
        mob:"Phone number  04423740554",
        Address: "10, Sbi Officers Colony,gill Nagar, Choolaimedu Chennai 600094",
        image: "images/groom8.jpg",
      },
      {
        ShopName: "Pet Pavillion",
        category: "Mumbai",
        mob:"Phone number  02223442349",
        Address: "Ground Floor Ganga Vihar, 94 Kazi Syed Street, Mumbai 400003",
        image: "images/groom9.jpg",
      }
    ],
  };
  
  for (let i of Shops.data) {
    //Create Card
    let card = document.createElement("div");
    //Card should have category and should stay hidden initially
    card.classList.add("card","clearfix",i.category, "hide");
    //image div
    // let imgContainer = document.createElement("div");
    //img tag
    let image = document.createElement("img");
    image.setAttribute("src", i.image);
    // imgContainer.appendChild(image);
    card.appendChild(image);
    //container
    let container = document.createElement("div");
    container.classList.add("card-content");
    //Shop name
    let name = document.createElement("h3");
    // name.classList.add("Shop-name");
    name.innerText = i.ShopName;
    container.appendChild(name);
    //Address
    let addrs = document.createElement("p");
    addrs.innerText = i.Address;
    container.appendChild(addrs);
    //mobile
    let contact = document.createElement("p");
    contact.innerText = i.mob;
    container.appendChild(contact);

    card.appendChild(container);
    document.getElementById("center").appendChild(card);
  }
  
  //parameter passed from button (Parameter same as category)
  function filterShop(value) {
    //Button class code
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
      //check if value equals innerText
      if (value.toUpperCase() == button.innerText.toUpperCase()) {
        button.classList.add("active");
      } else {
        button.classList.remove("active");
      }
    });
  
    //select all cards
    let elements = document.querySelectorAll(".card");
    //loop through all cards
    elements.forEach((element) => {
      //display all cards on 'all' button click
      if (value == "All") {
        element.classList.remove("hide");
      } else {
        //Check if element contains category class
        if (element.classList.contains(value)) {
          //display element based on category
          element.classList.remove("hide");
        } else {
          //hide other elements
          element.classList.add("hide");
        }
      }
    });
  }
  
  
  
  //Initially display all Shops
  window.onload = () => {
    filterShop("All");
  };