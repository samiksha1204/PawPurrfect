<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Login & Signup Form</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="style1.css">

</head>
<body>
	<div class="center">
		<div class="btns">
			<a class="a1" href="#">Sign up</a>
			<a class="a2" href="login.php">Log in</a>			
		</div>
		<div class="signup-form">
			<div class="header">Signup</div>
			<div class="signup_error"></div>
			<form name="signupForm" method="post" onsubmit="return signupValid();" action="register.php">
				<input type="text" name="firstname" placeholder="Firstname/ Name">
				<!-- <span class="d">*</span> -->
				<input class="lstname" name="lastname" type="text" placeholder="Lastname/ 'Shelter'">	
				<!-- <span class="d">*</span> -->
				<input class="email" name="email" type="text" placeholder="Email">	
				<!-- <span class="d">*</span> -->
				<input class="email" name="password" type="password" placeholder="Password">
				<input class="email" name="cpassword" type="password" placeholder="confirm Password">
				<input type="text" name="location" placeholder="location"">
				<input class="contact" name="contact" type="text" placeholder="contact">
				<!-- <label for="normal">User</label><input type="radio" name="who" id="normal" value="normal"> -->
				<!-- <label for="shelter">Animal Shelter</label><input type="radio" name="who" id="shelter" value="shelter"> -->
				<label class="rad-label">
					<input type="radio" class="rad-input" name="indiv">
					<div class="rad-design"></div>
					<div class="rad-text">Individual</div>
				  </label>
				
				  <label class="rad-label">
					<input type="radio" class="rad-input" name="shel">
					<div class="rad-design"></div>
					<div class="rad-text">Animal Shelter</div>
				  </label>
				  <input type="submit" value="Signup" name="reg-btn">

			</form>
		</div>
		<!-- <div class="login-form">
			<div class="header header1">Login</div>
			<div class="login_error"></div>
			<form name="loginform" method="post" onsubmit="return logincheck()">
				<input class="email" type="text" placeholder="Email" name="user">	
				<input class="email" type="password" placeholder="Password" name="pass">
				<input type="submit" value="Login">
			</form>
		</div> -->
	</div>
	<script src="script1.js"></script>
	<script src="valid.js"></script>
  
</body>
<?php 
    function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }
    if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['reg-btn'])){
            $server='localhost';
            $us='root';
            $con=mysqli_connect($server,$us,'');
            if(!$con){
                header("Location: error.php","http_response_code:400");
            }
            else{
              $dbname='pawpurrfect';
              mysqli_select_db($con,$dbname);
			  $fn=test_input($_POST['firstname']);
			  $ln=test_input($_POST['lastname']);
			  $em=test_input($_POST['email']);
			  $pass=test_input($_POST['password']);
			  $loc=test_input($_POST['location']);
			  $cont=test_input($_POST['contact']);
              if(isset($_POST['indiv'])){
              $idq="select max(uid) from users where uid<>99;";
              $result = mysqli_query($con,$idq);// or header("Location: error.php","http_response_code:400");;
              if(!$result){
              echo mysqli_error($con);
              }
              $row=mysqli_fetch_array($result);
              $oid=$row['max(uid)'];
			//   $fn=test_input($_POST['firstname']);
			//   $ln=test_input($_POST['lastname']);
			//   $em=test_input($_POST['email']);
			//   $pass=test_input($_POST['password']);
			//   $loc=test_input($_POST['location']);
			//   $cont=test_input($_POST['contact']);

			  $qchk='select uid from users where email="'.$em.'"';
			  $res=mysqli_query($con,$qchk);
			  $n=mysqli_num_rows($res);
			  if($n>0)
			  {
				  echo '<script>alert("Email id is already used by another account.");</script>';
			  }
			  else{
				  $query='insert into users values('.($oid+1).',"'.$fn.'","'.$ln.'","'.$em.'","'.$cont.'","'.$loc.'","'.$pass.'");';
				  $res=mysqli_query($con,$query);
				  if(!$res){
					echo 'hi2';
					  echo mysqli_error($con);
				  }
				  else{
					echo '<script>alert("You have registered successfully.")</script>';
				  }
			  }

            
              }
              else if(isset($_POST['shel'])){
              $idq="select max(aid) from animal_shelter;";
			  $result = mysqli_query($con,$idq);// or header("Location: error.php","http_response_code:400");;
              if(!$result){
              echo mysqli_error($con);
              }
              $row=mysqli_fetch_array($result);
              $oid=$row['max(aid)'];
			  $qchk='select aid from animal_shelter where email="'.$em.'"';
			  $res=mysqli_query($con,$qchk);
			  $n=mysqli_num_rows($res);
			  $fn=$fn.' '.$ln;
			  if($n>0)
			  {
				  echo '<script>alert("Email id is already used by another account.");</script>';
			  }
			  else{
				  $query='insert into animal_shelter values('.($oid+1).',"'.$fn.'","'.$em.'","'.$loc.'","'.$cont.'","'.$pass.'");';
				  $res=mysqli_query($con,$query);
				  if(!$res){
					//echo 'hi2';
					  echo mysqli_error($con);
				  }
				  else{
					echo '<script>alert("You have registered successfully.")</script>';
				  }
			  }

            
              }
             
            }
        }
    ?>
</html>