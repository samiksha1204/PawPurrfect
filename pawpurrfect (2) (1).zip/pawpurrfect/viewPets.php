<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View pets</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/viewpets.css">
    <link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
    <!-- navbar -->
    <?php include 'header.php';?>

    <!-- banner -->
    <div class="banner">
        <p>Find your dream pet here</p>
    </div>

    <!-- filter form -->
    <div class="container">
        <div class="row" class="filter">
            <form name="filters" action="viewPets.php" method="POST" class='f1' >
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="animal" class="filter-make form-control" id="atype" name='atype'>
                        <option value="0" disabled selected>Select Animal</option>
                        <option value="all">Show All</option>
                        <option value="cat">Cats</option>
                        <option value="dog">Dogs</option>
                    </select>
                </div>
                <input type='submit' name='fil1' value='Apply filter' class="button1">
                <!-- <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="breed" class="filter-model form-control">
                        <option value="0" disabled selected>Select Breed</option>
                        <option value="all">Show All</option>
                        <option value="pug">Pug</option>
                        <option value="golden_retriever">Golden retriever</option>
                        <option value="german_shephard">German shephard</option>
                        <option value="bulldog">Bulldog</option>
                        <option value="cockerspaniel">Cockerspaniel</option>
                        <option value="persian">Persian</option>
                        <option value="bengal">Bengal</option>
                        <option value="munchkin">Munchkin</option>
                        <option value="spotted">Spotted</option>
                        <option value="bombay">Bombay</option>
                        <option value="siamese">Siamese</option>
                    </select>
                </div>
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="type" class="filter-type form-control">
                        <option value="0" disabled selected>Select Gender</option>
                        <option value="all">Show All</option>
                        <option value="female">Female</option>
                        <option value="male">Male</option>
                    </select>
                </div>
                <div class="form-group col-sm-3 col-xs-6">
                    <select data-filter="city" class="filter-city form-control">
                        <option value="0" disabled selected>Select Location</option>
                        <option value="all">Show All</option>
                        <option value="mum">Mumbai</option>
                        <option value="del">Vellore</option>
                        <option value="kol">Kolkata</option>
                        <option value="chen">Chennai</option>
                    </select>
                </div> -->
            </form>
        </div>
    </div>

    <!-- main content -->
    <div class="wrapper">
        <div class="container-fluid">
            <?php 
            if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['fil1']) and $_POST['atype']!='all'){
                $anim=$_POST['atype'];
                $query="select animal_id,animal.uid,animal.aid,animal_type, name,image,fname from animal JOIN users where animal.uid=users.uid and animal.active=1 and animal_type='".$anim."';";
            }
            else{
                $query="select animal_id,animal.uid,animal.aid,animal_type, name,image,fname from animal JOIN users where animal.uid=users.uid and animal.active=1;";
            }
            $servername='localhost';
            $username='root';
            $con=mysqli_connect($servername,$username,'');
            if(!$con){ echo"Unable to connect"; die();}
            
            $dbname='pawpurrfect';
            mysqli_select_db($con,$dbname);

            
            $res=mysqli_query($con,$query);
            $n=mysqli_num_rows($res);
            $i=0;
            while($i<$n/4){
                $j=0;
                echo' <div class="row">';
                while($j<4){
                    $row = mysqli_fetch_array($res);
                    if($row){
                echo'<div class="col-sm-3 animal '.$row['animal_type'].'">';
                echo'<div class="card">';
                echo'<img src="'.$row["image"].'" alt="">';
                echo        '<div class="card-content">';
                $anim_id=$row["animal_id"];
                echo           '<p>'.$row["name"].'</p>';
                if($row['fname']=='adm'){
                    $q2='select name from animal_shelter where aid='.$row["aid"];
                    $res2=mysqli_query($con,$q2);
                    $row2 = mysqli_fetch_array($res2);
                    echo'<p><span>'.$row2["name"].'</span></p>';
                }
                else{
                echo            '<p>Owner : <span>'.$row["fname"].'</span></p>';}
                echo            '<form name="anim_details" method="POST" action="try.php"><input type="hidden" id="animid" name="animid" value="'.$anim_id.'"><input type=submit name="anim_det_btn" class="button1" value="View"></form>';
                echo        '</div>';
                        
                echo    '</div>';
                echo '</div>';
                    }
                    else{
                        break;
                    }
                    $j+=1;
                    
            }
            $i+=1;
            echo '</div>';
        }
            ?>
    </div>
    </div>

    <?php include 'footer.php';?>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
     <script type="text/javascript">
            function changetype(){
                var an=document.getElementById('atype').value;
                var list=document.getElementsByClassName('animal');
                for (var i=0;i<list.length;i++){
                    var arr=list[i].classList;
                    for (var j=0;j<arr.length;j++){
                        if(arr[j]==an){
                            list[i].style.display='block';
                        }
                        else{
                            list[i].style.display='none';
                        }
                    }
                }
                
            }
    </script>

</body>
</html>