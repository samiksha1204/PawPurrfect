<?php
session_start();
$shelterid = $_SESSION['user_id'];
$userid = 99;

$con = mysqli_connect('localhost','root','');
if(!$con){
    echo 'con issue';
}
else{
    echo'con done';
}
$dbname='pawpurrfect';
 mysqli_select_db($con,$dbname);
if(isset($_POST['save_pet']))
{
    $idq="select max(animal_id) from animal;";
			  $result = mysqli_query($con,$idq);// or header("Location: error.php","http_response_code:400");;
              if(!$result){
              echo mysqli_error($con);
              }
              $row=mysqli_fetch_array($result);
              $a_id=$row['max(animal_id)']+1;
    $name = $_POST['pet_name'];
    //$a_id = $_POST['pet_id'];
    $breed = $_POST['pet_breed'];
    $vacc = $_POST['pet_vacc'];
    $age = $_POST['pet_age'];
    $gen =$_POST['pet_gen'];
    $img = $_FILES['pet_img']['name'];
    $type = $_POST['type'];

    $query = "insert into animal (animal_id,uid,aid,name,animal_type,breed,vaccination_details,age,gender,image,active) 
    values ($a_id,$userid,$shelterid,'$name','$type','$breed','$vacc',$age,'$gen','images/$img',1);";
    $res = mysqli_query($con,$query);
    if($res)
    {
        move_uploaded_file($_FILES['pet_img']['name'],"images/".$_FILES['pet_img']['name']);
        $_SESSION['status'] = 'image stored successfully';
        header('Location: create.php');
    }
    else{
        $_SESSION['status'] = 'image not uploaded';
        echo mysqli_error($con);
        //header('Location: create.php');
    }
}

?>