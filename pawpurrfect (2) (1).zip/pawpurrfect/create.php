
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Image Upload</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/homepage.css">
</head>
<body>
    <?php include 'header.php' ?>
    <div class="container mt-4">
        <div class="row">
            <div class="col-md-12">
                <div class="card">

                    <div class="card-header">
                        <h4>Upload animal</h4>
                    </div>
                    <div class="card-body">
                        <?php
                            if(isset($_SESSION['status']) && $_SESSION  != '')
                            {
                                ?>
                               <div class="alert alert-warning" role="alert"> 
                                <?php echo $_SESSION['status']; ?>  
                              
                                </div>
                                <?php
                                unset($_SESSION['status']);
                            }
                        ?> 
                    
                         
                        <form action="code.php" method="post" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="">Name</label>
                            <input type="text" name="pet_name" required class="form-control" placeholder="Enter Name" id="">
                        </div>
                        <!-- <div class="form-group">
                            <label for="">animal Id</label>
                            <input type="text" name="pet_id" required class="form-control" placeholder="Enter Name" id="">
                            
                        </div> -->
                        <div class="form-group">
                            <select name="type" id="">
                                <option value="cat">cat</option>
                                <option value="dog">dog</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="">Breed</label>
                            <input type="text" name="pet_breed" required class="form-control" placeholder="Enter Breed" id="">
                            
                        </div>
                        <div class="form-group">
                            <label for="">Vaccination Details</label>
                            <input type="text" name="pet_vacc" required class="form-control" placeholder="Enter Vaccination details" id="">
                            
                        </div>
                        <div class="form-group">
                            <label for="">Age</label>
                            <input type="text" name="pet_age" required` class="form-control" placeholder="Enter Age" id="">
                            
                        </div>
                        <div class="form-group">
                            <label for="">Gender</label>
                            <input type="text" name="pet_gen" class="form-control" required placeholder="Enter Gender" id="">
                            
                        </div>
                        <div class="form-group">
                            <label for="">Photo</label>
                            <input type="file" name="pet_img" required class="form-control" id="">
                            
                        </div>
                        <div class="form-group">
                            <button type="submit" name="save_pet" class='btn btn-primary'>Upload Image</button>
                        </div> 
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php include 'footer.php'?>
    <!-- <h1>Hello World</h1> -->
</body>
</html>