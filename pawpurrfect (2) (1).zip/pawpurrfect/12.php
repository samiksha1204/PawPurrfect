<?php
require('config.php');
// echo ;
$amt =  $_POST['amount']*100;
$n = $_POST['shelter'];
?>
<form action="submit.php" method="POST">
    <script
        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
        data-key="<?php echo $publishableKey; ?>"
        data-amount= "<?php echo $amt ?>"
        data-name= "<?php echo $n ?>"
        data-description ="Donated for animal welfare"
        data-currency = "inr"
        data-email='pawpurrfect@gmail.com'
    >
    </script>
</form>
<!-- token generated for each transaction and sent to submit.php -->
