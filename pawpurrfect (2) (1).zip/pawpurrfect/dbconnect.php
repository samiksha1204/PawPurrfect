<?php 
 $servername='localhost';
 $username='root';
 $con=mysqli_connect($servername,$username,'');
 if(!$con){ header("Location: error.php","http_response_code:400");//echo"Unable to connect"; die();
}
 
 $dbname='pawpurrfect';
 mysqli_select_db($con,$dbname);

?>