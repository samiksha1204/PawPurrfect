<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Homepage</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/homepage.css">
</head>
<body>
    <!-- <header style="background-color: darkturquoise;">
    <ul>
        <li class="Brand"><a href="#">PawPurrfect</a></li>
        <li><a href="#" >Home</a></li>
        <li><a href="#">Adopt</a></li>
        <li><a href="#">Donate</a></li>
        <li><a href="#">Contact Us</a></li>
        <li style="float:right"><a href="#">Login | Register</a></li>
    </ul>
</header> -->
<?php include 'header.php';?>
<div class="banner">
    <p>A true friend leaves paw prints on your heart.</p>
</div>
<div class="container content">
    <div class="row">
        <div class="col-lg-6">
            <img class="logo img-responsive" src="images\Beige Love Couple Valentine Collage.jpg">
        </div>
        <div class="col-lg-6 para">
            Every year, approximately 6.5 million pets enter animal shelters nationwide, and 1.5 million become euthanized. And with the current shelter crisis, numbers are on the rise. But you can help!
            <br><br>
            Not only are pets scientifically proven to reduce stress levels and improve blood pressure, but no one can offer the unconditional love and companionship a pet can.
            When you get a dog from a pet store, the transaction usually ends once you exit the door. Many pet stores don’t have the resources or knowledge to provide any support if you have questions or problems with your new pet.
            <br>
            <br>
However, shelters and rescue groups usually have history on the animal, and the volunteers get to know the animal’s personality and likes and dislikes. This helps ease the transition, and more often than not, 
shelters are happy to help you through the introductory period because they care that the animal goes to a happy home.
<br><br>
Not only do animals give you unconditional love, but they have been shown to be psychologically, emotionally and physically beneficial to their companions. Caring for a pet can provide a sense of purpose and fulfillment and lessen feelings of loneliness. And when you adopt, you can also feel proud about helping an animal in need!


        </div>
    </div>
</div>
<!-- <div class="footer-basic">
    <footer>
        <div class="social">
            <a href="#"><i class="fa fa-facebook"></i></a>
            <a href="#"><i class="fa fa-instagram"></i></a>
            <a href="#"><i class="fa fa-twitter"></i></a>
            <a href="#"><i class="fa fa-linkedin"></i></a>
        </div>
        <ul class="list-inline">
            <li class="list-inline-item"><a href="#">Home</a></li>
            <li class="list-inline-item"><a href="#">Services</a></li>
            <li class="list-inline-item"><a href="#">About</a></li>
            <li class="list-inline-item"><a href="#">Terms</a></li>
            <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
        </ul>
        <p class="copyright">Pawpurrfect © 2022</p>
    </footer>
</div> -->
<?php include 'footer.php';?>
</body>
</html>