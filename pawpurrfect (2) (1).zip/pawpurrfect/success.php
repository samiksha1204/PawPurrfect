<html>
    <head>
        <title>Payment successfull </title>
        <style>
            div
            {
                text-align: center;
                color: darkturquoise;
                margin: 0 auto;
                margin-top: 100px;
                margin-bottom: 80px;
                width:900px;
                box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 12px;
                border-radius: 10px;
                padding: 20px;
                font-size: 25px;
            }
            div a{
                text-decoration: none;
                color : pink;
                font-size:20px;
            }
        </style>
    </head>
    <body>
    <div>
        <h3>Thank you for your Donation! Have a nice day</h3>
        <a href='homepage.php'>Back to homepage</a>
    </div>
    </body>
    
</html>