var pass = document.forms['signupForm']['pass'];
var email = document.forms['signupForm']['email'];
// var password = document.forms['signupForm']['password'];
// var cpassword = document.forms['signupForm']['cpassword'];
var signup_error = document.querySelector('.signup_error');
// var count = 0;
// firstname.addEventListener('textInput', fstnameVerify);
// lastname.addEventListener('textInput', lstnameVerify);
// email.addEventListener('textInput', emailVerify);
// password.addEventListener('textInput', passwordVerify);
// var login_name = document.forms['loginform']['user'];
// var login_pass = document.forms['loginform']['pass'];

function signupValid(){

     if (email.value.length <= 8) {
		signup_error.style.display = "block";
		email.style.border = "1px solid red";
		signup_error.innerText = "Please Fill up Your Email";
        // alert('Please Fill up Your Email');
		email.focus();
		return false;
	}
    if(pass.value.length < 1){
		signup_error.style.display = "block";
		pass.style.border = "1px solid red";
		signup_error.innerText = "Please Fill up Your Password";
		pass.focus();
		return false;
}
}