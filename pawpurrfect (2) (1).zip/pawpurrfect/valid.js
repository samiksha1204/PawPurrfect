var firstname = document.forms['signupForm']['firstname'];
var lastname = document.forms['signupForm']['lastname'];
var email = document.forms['signupForm']['email'];
var password = document.forms['signupForm']['password'];
var cpassword = document.forms['signupForm']['cpassword'];
var signup_error = document.querySelector('.signup_error');
var contact = document.forms['signupForm']['contact'];
var loc = document.forms['signupForm']['location'];
var count = 0;
// firstname.addEventListener('textInput', fstnameVerify);
// lastname.addEventListener('textInput', lstnameVerify);
// email.addEventListener('textInput', emailVerify);
// password.addEventListener('textInput', passwordVerify);
// var login_name = document.forms['loginform']['user'];
// var login_pass = document.forms['loginform']['pass'];

function signupValid(){
	if (firstname.value.length <= 2) {
		signup_error.style.display = "block";
		firstname.style.border = "1px solid red";
		// document.getElementsByClassName('d').style.color='red';
		signup_error.innerText = "Please Fill up Your Firstname";
		firstname.focus();
		return false;
	}
	else if(!checkname(firstname.value)){
		signup_error.style.display = "block";
		signup_error.innerText = "Only alphabets allowed";
		return false;

	}
	else if (lastname.value.length <= 2) {
		signup_error.style.display = "block";
		lastname.style.border = "1px solid red";
		signup_error.innerText = "Please Fill up Your Lastname";
		lastname.focus();
		return false;
	}
	else if(!checkname(lastname.value))
	{
		signup_error.style.display = "block";
		signup_error.innerText = "Only alphabets allowed";
		return false;
	}
	if (email.value.length <= 8) {
		signup_error.style.display = "block";
		email.style.border = "1px solid red";
		signup_error.innerText = "Please Fill up Your Email";
		email.focus();
		return false;
	}
	else if(!checkmail(email.value))
	{
		signup_error.style.display = "block";
		signup_error.innerText = "Email not valid";
		return false;
	}
	if (password.value.length <= 8) {
		signup_error.style.display = "block";
		password.style.border = "1px solid red";
		signup_error.innerText = "Your password must be at least 8 characters";
		var p = password.value;
		if (p.search(/[a-z]/i) < 0) {
			signup_error.innerText = "Your password must contain at least one letter.";
		}
		if (p.search(/[0-9]/) < 0) {
			signup_error.innerText = "Your password must contain at least one digit."; 
		}
		password.focus();
		return false;
	}
	else if(password.value.length < 1){
		signup_error.style.display = "block";
		password.style.border = "1px solid red";
		signup_error.innerText = "Please Fill up Your Password";
		password.focus();
		return false;
	}
	if((cpassword.value.length != password.value.length )||(cpassword.value !== password.value)){
		signup_error.style.display="block";
		cpassword.style.border = "1px solid red";
		signup_error.innerText = "Please re-enter correct Password";
		return false;
	}
	if(contact.value.length<10)
	{
		signup_error.style.display="block";
		cpassword.style.border = "1px solid red";
		signup_error.innerText = "invalid contact";
		return false;
	}
	else if(!checkmob(contact.value))
	{
		signup_error.style.display = "block";
		signup_error.innerText = "mob not valid";
		return false;
	}
	if(loc.value.length < 1)
	{
		signup_error.style.display="block";
		cpassword.style.border = "1px solid red";
		signup_error.innerText = "enter location";
		return false;
	}
	else if (!in_loc(loc.value))
	{
		signup_error.style.display = "block";
		signup_error.innerText = "Not a valid location";
		return false;
	}
}
function in_loc(str){
	var arr = ['delhi','mumbai','chennai','kolkata','vellore','bangalore'];
	for(i = 0 ; i<arr.length;i++){
		if(str.toLowerCase() == arr[i]){
			console.log(arr[i]);
			return true;
		}
	}
	return false;
}
function checkmob(str){
	pattern = /^[1-9][0-9]{9}$/;
	if(!str.match(pattern))
		return false;
	return true;
}
function checkname(str)
{
	pattern =/^[a-zA-Z\s]+$/;
	if(!str.match(pattern))
		return false;
	return true;
	
}
function checkmail(str)
{
	pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	console.log('called');
	if(str.match(pattern))
	{
		console.log('Invalid');
		return true;
	}
	else{
	return false;
	}
}
// function fstnameVerify(){
// 	if (firstname.value.length > 1) {
// 		signup_error.style.display = "none";
// 		firstname.style.border = "1px solid #3498db";
// 		signup_error.innerText = "";
// 		return true;
// 	}
// }
// function lstnameVerify(){
// 	if (lastname.value.length > 1) {
// 		signup_error.style.display = "none";
// 		lastname.style.border = "1px solid #3498db";
// 		signup_error.innerText = "";
// 		return true;
// 	}
// }
// function emailVerify(){
// 	if (email.value.length > 7) {
// 		signup_error.style.display = "none";
// 		email.style.border = "1px solid #3498db";
// 		signup_error.innerText = "";
// 		return true;
// 	}
// }
// function passwordVerify(){
// 	if (password.value.length > 2) {
// 		signup_error.style.display = "none";
// 		password.style.border = "1px solid #3498db";
// 		signup_error.innerText = "";
// 		return true;
// 	}
// }
function logincheck()
{
	if(login_pass.value.length < 1){
		
		login_error.style.display = "block";
		login_pass.style.border = "1px solid red";
		login_error.innerText = "Please Fill up Your password";
		login_pass.focus();
		return false;
	}
	if (login_user.length <= 8) {
		login_error.style.display = "block";
		login_user.style.border = "1px solid red";
		login_error.innerText = "Please Fill up Your Email";
		login_user.focus();
		return false;
	}
}