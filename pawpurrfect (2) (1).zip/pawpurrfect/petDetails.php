<!DOCTYPE html>
<html lang="en">
<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="css/petdetsstyle.css">
        <title>Animal Details</title>
    </head>
    <body>
        <?php include 'header.php';?>
        <div id="main">
        <?php $server='localhost';
        $us='root';
        $con=mysqli_connect($server,$us,'');
        if(!$con){
            header("Location: error.php","http_response_code:400");}
                ?>
            <header>
                <?php 
            
                $animi=$_COOKIE['animid'];
                $dbname='pawpurrfect';
                mysqli_select_db($con,$dbname);
                $query="SELECT animal_id,animal.uid,aid,name,age,breed,gender,vaccination_details,image, users.location,users.contact from animal JOIN users where animal.uid=users.uid and animal_id=$animi;";
      $result = mysqli_query($con,$query);
      if(!$result){
        echo mysqli_error($con);
      }
      $row=mysqli_fetch_array($result);?>
                    <h1 class="name">Meet <?php echo $row['name'].'!';?></h1>
            </header>
            
            <div class="pet">
                <figure>
                    <?php 
                    echo '<img src="'.$row['image'].'">';?>
                </figure>
                    <ul>
                        <li><b>Age: </b><?php echo $row['age'];?></li>
                        <li><b>Breed: </b><?php echo $row['breed'];?></li>
                        <li><b>Gender: </b><?php echo $row['gender'];?></li>
                        <li><b>Location: </b><?php if($row['uid']==99){
                            $q2='select address,contact from animal_shelter where aid='.$row["aid"];
                            $res2=mysqli_query($con,$q2);
                            $row2 = mysqli_fetch_array($res2);
                            echo $row2["address"].'</li>';
                            echo '<li><b>Contact: </b> '.$row2["contact"].'</li>';
                        }
                        else{
                            echo $row["location"].'</li>';
                            echo '<li><b>Contact: </b> '.$row["contact"].'</li>';}
                        ?>
                        <li><b>Vaccination Details: </b><?php echo $row['vaccination_details'];?></li>  
                        <li>
                            <button class="butt" onclick="adopt_pet();" >Adopt!</button>  

                        </li>
                    </ul>
            </div>

        </div>
        <script type="text/javascript">
            function adopt_pet(){
                var choice=confirm("Are you sure you want to adopt this pet");
                console.log(choice);
                if(choice==true){
                     window.location.href="confirm_adopt.php";
                }
            }
            </script>
    <!-- <div class="footer-basic">
        <footer>
            <div class="social">
                <a href="#"><i class="fa fa-facebook"></i></a>
                <a href="#"><i class="fa fa-instagram"></i></a>
                <a href="#"><i class="fa fa-twitter"></i></a>
                <a href="#"><i class="fa fa-linkedin"></i></a>
            </div>
            <ul class="list-inline">
                <li class="list-inline-item"><a href="#">Home</a></li>
                <li class="list-inline-item"><a href="#">Services</a></li>
                <li class="list-inline-item"><a href="#">About</a></li>
                <li class="list-inline-item"><a href="#">Terms</a></li>
                <li class="list-inline-item"><a href="#">Privacy Policy</a></li>
            </ul>
            <p class="copyright">Pawpurrfect © 2022</p>
        </footer>
    </div> -->
    <?php include 'footer.php';?>
    </body>
</html>