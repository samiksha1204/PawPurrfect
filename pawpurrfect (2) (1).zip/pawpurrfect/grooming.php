<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grooming</title>
    <link rel="stylesheet" href="grooming.css">
    <!-- <meta http-equiv="refresh" content="5"> -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
    <?php include 'header.php' ?>    
    <div class="box1">
        <div class="box1-content">
            <div class="para-left">
                <h1>Basic Types Of Grooming Every Pet Should Get</h1>
                <p>
                Pet grooming is an important part of the hygiene and emotional well being of your animal. Doesn’t feel good when you get your hair cut or nails done? Imagine not having the luxury of choosing how and when you clean yourself.
                Pet grooming at a young age also allows the animal to get used to the tools and apparatus used in the
                pet grooming experience.
                </p>
                <!-- <button>learn more</button> -->
            </div>
            <div class="features">
                <ul>

                    <li><span class="fa fa-check"></span>Bathing keeps your pet clean</li>
                    <li><span class="fa fa-check"></span>Nail trimming, reward your pet each time you successfully finish cutting its nails.</li>
                    <li><span class="fa fa-check"></span>Ear care reduces risk of yeast and bacterial infection, which could make them ill.</li>
                    <li><span class="fa fa-check"></span>Fur brushing with the right brush. </li>
                    <li><span class="fa fa-check"></span>Without haircut the grooming is not complete</li>
                </ul>
            </div>
        </div>
    </div>
    <div class="box2" id="center">
        <div id="buttons">
            <button class="button-value show-all" onclick="filterShop('All')">All</button>
            <button class="button-value" onclick="filterShop('Delhi')">Delhi</button>
            <button class="button-value" onclick="filterShop('Mumbai')">Mumbai</button>
            <button class="button-value" onclick="filterShop('Chennai')">Chennai</button>
            <button class="button-value" onclick="filterShop('Kolkata')">Kolkata</button>

        </div>
    </div>   
    <script src="grooming.js"></script>
    <?php include 'footer.php' ?>
</body>
</html>