<header style="background-color: darkturquoise;">

        <ul>
            <li class="Brand" style='font-family: "Homemade Apple", cursive'><a href="homepage.php">PawPurrfect</a></li>
            
            
            <?php
            session_start();
            if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['logout-btn'])){
                session_unset();
                session_destroy();
                header("Location: homepage.php");
            }
            
            if(isset($_SESSION['user_id'])){
                if($_SESSION['user_type']=='normal'){
                echo '<li><a href="viewPets.php">Adopt</a></li>';
                echo  '<li><a href="index.php">Donate</a></li>';
                }
                else if($_SESSION['user_type']=='shelter'){
                    // echo '<li><a href="viewPets.php">Adopt</a></li>';
                    echo  '<li><a href="create.php">Add profile</a></li>';
                    }
            echo'<li style="float: right" class="adjust"><a href="editprofile.php">View Profile |</a>';
            echo'<form name="logout" method="POST" action="header.php">';
            echo'<input type="submit" value="Log out" name="logout-btn" class="lo" style="background-color:darkturquoise;border: none;"></li></form>';
            }
            else if(!isset($_SESSION['user_id'])){
            echo '<li><a href="viewPets.php">Adopt</a></li>';    
            echo'<li style="float:right"><a href="register.php">Login | Register</a></li>';
            }
            
           
                ?>
            <li><a href="grooming.php">Grooming Center</a></li>
            <li><a href="blog.php">Blog</a></li> 
            <!-- <li><a href="#">Contact Us</a></li> -->
        </ul>
    </header>