<?php 
    if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['anim_det_btn']))
    {
        $pet_name=$_POST['animid'];
        setcookie("animid",$pet_name);
        header("Location:petDetails.php"); 
    }
    
?>