<?php
require('stripe-php-master/init.php');
//secret,publishable key variable
$publishableKey = "pk_test_51L6zkOSD10bHKRc0arlCNFzwliAZ1g8AFYua9jbhk3ZK69LFKxFp9Xo7YL3KEwiwdBnQnft7o03YBlhDWvnmawXt00SuzIyjnF";
$secretKey = "sk_test_51L6zkOSD10bHKRc0BuBJHd93kflwxuaTSEty9qhBCJjJowIjTehKdJ4dfMc3nlYDD64jswBCO0JzRsvUBK9rX2Dm00m92kXDzb";

//set key namespace
\Stripe\Stripe::setApiKey($secretKey);
?>