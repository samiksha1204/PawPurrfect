<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Yolo</title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
    <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/> -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="login.css">

</head>
<body>
	<div class="center">
		<div class="btns">
			<a class="a1" href="register.php">Sign up</a>
			<a class="a2" href="#">Log in</a>			
		</div>
		<!-- <div class="signup-form">
			<div class="header">Signup</div>
			<div class="signup_error"></div>
			<form name="signupForm" method="post" onsubmit="return signupValid()">
				<input type="text" name="firstname" placeholder="Firstname"">
				
				<input class="lstname" name="lastname" type="text" placeholder="Lastname"">	
				
				<input class="email" name="email" type="text" placeholder="Email"">	
				
				<input class="email" name="password" type="password" placeholder="Password"">
				<input class="email" name="cpassword" type="password" placeholder="confirm Password"">
				<input type="text" name="location" placeholder="location"">
				<input class="contact" name="contact" type="text" placeholder="contact"">
				<input type="submit" value="Signup">
			</form>
		</div>-->
		<div class="login-form">
			<div class="header header1">Login</div>
			<div class="signup_error"></div>
			<form name="signupForm" method="post" onsubmit="return signupValid();" action="login.php">
				<input class="email" name="email" type="text" placeholder="Email">	
                <input type="password" class="email" placeholder="Password" name="pass">
                <input type="submit" value="Signup" name='login-btn'>
            </form>
		</div> 
	</div>
	<!-- <script src="script.js"></script>
	<script src="valid.js"></script> -->
    <script>
        var signup_link = document.querySelector('.a1');
var login_link = document.querySelector('.a2');

// var signup_form = document.querySelector('.signup-form');
var login_form = document.querySelector('.login-form');

login_link.addEventListener('click', signup_hide);
signup_link.addEventListener('click', login_hide);

function signup_hide(){
	signup_form.style.display = "none";
	login_form.style.display = "block";
	// signup_link.style.background = "darkturquoise";
	login_link.style.background = "pink";
	// login_link.style.textDecoration ='underline';
	signup_link.style.background ='none';
	signup_link.style.textDecoration ='none';
}
function login_hide(){
	signup_form.style.display = "block";
	login_form.style.display = "none";
	signup_link.style.background = "pink";
	// login_link.style.background = "darkturquoise";
	// signup_link.style.textDecoration ='underline';
	login_link.style.textDecoration ='none';
	login_link.style.background ='none';
}
    </script>
    <script src="loginvalid.js"></script>
<?php
 function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$em_err=$ps_err="";
if($_SERVER['REQUEST_METHOD']=='POST' and isset($_POST['login-btn'])){
    $emip=test_input($_POST["email"]);
    $em_err=$emip; 
    $pwd=test_input($_POST["pass"]);
        $server='localhost';
        $us='root';
        $con=mysqli_connect($server,$us,'');
        if(!$con){
            header("Location: error.php","http_response_code:400");
        }
        else{
          $dbname='pawpurrfect';
          mysqli_select_db($con,$dbname);
          $query="select uid,passwrd from users where email ='$emip' union select aid,passwrd from animal_shelter where email ='$emip';";
$result = mysqli_query($con,$query);// or header("Location: error.php","http_response_code:400");;
if(!$result){
  echo mysqli_error($con);
}
//$em_err=$result;
$row=mysqli_fetch_array($result);
$i=mysqli_num_rows($result);
if($i==0|| $row['passwrd']!=$pwd){
echo '<script>alert("Invalid username or password");</script>';
}
else if($row["passwrd"]==$pwd)
{ 
session_start();
$_SESSION['user_id']=$row["uid"];
if($row["uid"]>100)
$_SESSION['user_type']="shelter";
else
$_SESSION['user_type']="normal";
header("Location: homepage.php"); /* Redirect browser */
} 
        }
    }


?>
</body>
</html>