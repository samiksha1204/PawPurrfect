<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Blog Page</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Homemade+Apple&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Caveat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hubballi&display=swap" rel="stylesheet">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hubballi&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/blog.css">
    <link rel="stylesheet" href="css/homepage.css"><meta name="viewport" content="width=device-width,initial-scale=1.0">
</head>
<body>
    <?php include "header.php"; ?>
    <!-- blog sectio -->
    <section id="blog">
        <div class="blog-heading">
            <span>Want to adopt? Know more about how to care for pets </span>
            <h3>Blog</h3>
        </div>

        <!-- blog-container    -->
        <div class="blog-container">
            <!-- box1 -->
            <div class="blog-box">
                <!-- img -->
                <div class="blog-img">
                    <img src="images/blog1.jpg" alt="Blog1">
                </div>
                <div class="blog-text">
                    <span>July 18 2020 / Adoption is Beautiful</span>
                    <a href="https://www.humanesociety.org/resources/top-reasons-adopt-pets" class="blog-title" target="_blank">THE BEAUTY OF ADOPTION!</a>
                    <p>Thinking of adding a pet to your family? Here are 10 reasons to consider adopting a dog or cat from an animal shelter or rescue.</p>
                    <a href="https://www.humanesociety.org/resources/top-reasons-adopt-pets">Read More</a>
                </div>
            </div>
            <!-- box1 -->
            <div class="blog-box">
                <!-- img -->
                <div class="blog-img">
                    <img src="images/blog2.jpg" alt="Blog1">
                </div>
                <div class="blog-text">
                    <span>August 21 2021 / Care</span>
                    <a href="https://animalfoundation.com/whats-going-on/blog/basic-necessities-proper-pet-care" class="blog-title" target="_blank">The Basic Necessities of Proper Pet Care</a>
                    <p>Proper pet care is the basis of responsible pet ownership. It is important when you adopt a pet to understand it is a lifetime commitment to a furry family member that depends on you for his or her health and well-being. </p>
                    <a href="https://animalfoundation.com/whats-going-on/blog/basic-necessities-proper-pet-care">Read More</a>
                </div>
            </div>
            <!-- box1 -->
            <div class="blog-box">
                <!-- img -->
                <div class="blog-img">
                    <img src="images/blog3.jpg" alt="Blog1">
                </div>
                <div class="blog-text">
                    <span>May 2 2022 / Food</span>
                    <a href="https://www.petmd.com/dog/nutrition/evr_dg_principles_of_dog_nutrition" class="blog-title">Dogs and Cats Have Different Needs</a>
                    <p>Your pet may love to eat food fresh from your plate. But just because they like it doesn’t mean it’s good for them.
                    </p>
                    <a href="https://www.petmd.com/dog/nutrition/evr_dg_principles_of_dog_nutrition">Read More</a>
                </div>
            </div>
        </div>
    </section>
    <?php include "footer.php" ?>
</body>
</html>